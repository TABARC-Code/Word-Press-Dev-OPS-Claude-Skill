# Skill Network — Bidirectional Relationship Specifications

This file defines the complete bidirectional link contracts for `wordpress-studio`.
Every relationship is explicit, directional, and role-defined.
No casual references. No placeholder sections.

---

## Network Overview

```
wordpress-studio
    |
    |--- [A] professional-technical-writing  (bidirectional)
    |--- [B] skill-creator                   (bidirectional)
    |--- [C] alchemy-hive                    (bidirectional)
    |--- [D] boardgame-design-hydra          (bidirectional)
    |--- [E] humanizer                       (bidirectional)
    |
    Cross-links:
    [A] <--> [E]   (documentation clarity feeds humanizer; humanizer feeds back)
    [B] <--> [A]   (skill docs feed technical-writing; writing standards feed skill structure)
    [C] <--> [A]   (SEO content strategy feeds documentation structure)
```

---

## Relationship Table

| Source | Target | Type | Direction | Trigger Condition |
|---|---|---|---|---|
| wordpress-studio | professional-technical-writing | Output handoff | Outbound | Any user-facing text generated |
| professional-technical-writing | wordpress-studio | Standards feed | Inbound | Clarity rules applied to inline docs |
| wordpress-studio | skill-creator | Architecture feed | Outbound | Skill wrapping WordPress, or self-audit |
| skill-creator | wordpress-studio | Improvement loop | Inbound | Eval methodology, description refinement |
| wordpress-studio | alchemy-hive | Structure data | Outbound | SEO-relevant architecture decisions |
| alchemy-hive | wordpress-studio | Intent signals | Inbound | Page role assignments, search ecology |
| wordpress-studio | boardgame-design-hydra | Data modelling | Outbound | Rule/state/branching logic in plugin work |
| boardgame-design-hydra | wordpress-studio | Mechanic patterns | Inbound | Balance logic, decision tree clarity |
| wordpress-studio | humanizer | Raw prose | Outbound | All generated documentation text |
| humanizer | wordpress-studio | Cleaned prose | Inbound | AI-pattern-free copy returned |

---

## Full Relationship Definitions

---

### Link 1: wordpress-studio <--> professional-technical-writing

#### Outbound (wordpress-studio > professional-technical-writing)

**What wordpress-studio sends:**
- Function signatures with parameter types and return types
- Plugin file structure and section hierarchy
- Hook registration patterns (action/filter, priority, argument count)
- Admin interface copy (notices, labels, button text, descriptions)
- Readme file content (plugin description, installation, FAQ, changelog)
- Inline code comments for public-facing APIs

**Why it sends this:**
Code documentation must meet professional technical writing standards. A developer
who writes clear PHP does not automatically write clear English. The handoff ensures
user-facing and developer-facing documentation is unambiguous, consistently structured,
and reader-centred rather than code-centred.

**What changes in wordpress-studio as a result:**
- All generated readme sections follow Module 1 structure (installation, getting started,
  troubleshooting, warnings in correct order)
- All admin notices and user-facing strings follow Module 2 clarity rules (active voice,
  imperative where appropriate, no padding)
- All PHPDoc parameter descriptions follow Module 2 word economy rules

#### Inbound (professional-technical-writing > wordpress-studio)

**What professional-technical-writing sends back:**
- Sentence structure rules for inline code comments
- Terminology consistency enforcement (one term per concept)
- Warning-before-instruction rule applied to security-sensitive function documentation
- Module 3 layout standards for readme files (heading hierarchy, bullet formatting)
- Module 4 grammar corrections for any generated English prose

**What changes in professional-technical-writing as a result of this link:**
- professional-technical-writing gains WordPress-specific vocabulary context:
  hook names, sanitisation function names, WPCS conventions are not flagged as jargon
  to simplify — they are domain-correct terms to preserve
- professional-technical-writing applies Module 1 structure mapping to plugin readme
  sections (Introduction = About, Installation = Installation, FAQ = Troubleshooting)

---

### Link 2: wordpress-studio <--> skill-creator

#### Outbound (wordpress-studio > skill-creator)

**What wordpress-studio sends:**
- WordPress domain vocabulary for YAML trigger construction
- Hook-and-filter patterns as analogues for skill activation logic
- Plugin architecture (separation of concerns, single responsibility) as structural
  model for skill file organisation
- PHP DocBlock conventions as a model for skill frontmatter specification

**Why it sends this:**
Skill architecture and plugin architecture share structural DNA. Both require clean
separation of concerns, explicit contracts between components, and clear activation
conditions. The WordPress hook system — register once, fire when conditions are met — is
a direct architectural parallel to skill triggering.

**What changes in wordpress-studio as a result:**
- This skill's own YAML frontmatter is held to skill-creator eval standards
- Trigger vocabulary in this skill's description is optimised using skill-creator's
  description optimisation methodology
- Bidirectional link contracts in this file follow the link architecture standards
  defined in skill-creator's methodology

#### Inbound (skill-creator > wordpress-studio)

**What skill-creator sends back:**
- Eval loop methodology: how to test whether wordpress-studio is triggering correctly
- Description optimisation: which trigger phrases produce reliable activation
- Positive/negative feedback loop structure for skill self-improvement
- SKILL.md structural standards: frontmatter, progressive disclosure, reference file
  organisation

**What changes in skill-creator as a result of this link:**
- skill-creator gains a concrete domain example for its own documentation: WordPress
  plugin architecture as an analogy for skill component separation
- skill-creator's link architecture methodology is validated and refined through
  the complex multi-skill network defined here

---

### Link 3: wordpress-studio <--> alchemy-hive

#### Outbound (wordpress-studio > alchemy-hive)

**What wordpress-studio sends:**
- Custom post type slugs and their semantic roles
- Taxonomy structures and their relationship to content categories
- REST API endpoint designs and URL patterns
- Site architecture decisions (what content lives where, how it is related)
- WooCommerce product/category/tag taxonomy structures
- Page template assignments and their functional roles

**Why it sends this:**
WordPress site architecture directly determines search ecology. Post type slugs become
URL segments. Taxonomy structures determine faceted navigation and internal linking
patterns. REST endpoints determine how content is distributed. These structural decisions
must align with SEO intent signals to avoid architecture that works technically but
undermines search performance.

**What changes in wordpress-studio as a result:**
- Custom post type registration includes SEO-aware slug selection (not just
  technical convenience slugs)
- Taxonomy hierarchies are designed with Scout/Follower/Memory/Outlier page role
  awareness — category archive pages are not afterthoughts
- REST endpoint design considers content distribution and canonical URL implications

#### Inbound (alchemy-hive > wordpress-studio)

**What alchemy-hive sends back:**
- Page role assignments: which post types serve as Scout (discovery), Follower
  (conversion), Memory (authority), or Outlier (counterfactual/long-tail) pages
- Hidden intent analysis: what users actually want from a post type vs. what the
  client thinks they want
- Costly signal identification: which content types warrant high-effort production
  as trust signals
- Internal linking logic: which post types should link to which others and why

**What changes in alchemy-hive as a result of this link:**
- alchemy-hive gains WordPress-specific implementation context: page role assignments
  can be mapped to concrete WordPress template files, not just abstract content strategy
- alchemy-hive's Bee Colony model gains a data pipeline: custom post types and
  taxonomies provide the structured data that waggle-dance research patterns can operate on

---

### Link 4: wordpress-studio <--> boardgame-design-hydra

#### Outbound (wordpress-studio > boardgame-design-hydra)

**What wordpress-studio sends:**
- Custom post type schemas as data modelling patterns (analogous to card/unit stat blocks)
- Hook-based event systems as analogues for game event triggers
- User role and capability systems as analogues for player faction/asymmetric ability rules
- Transient/cache logic as analogues for hidden state and fog-of-war mechanics
- WooCommerce order state machine as analogue for game phase progression

**Why it sends this:**
This link is active specifically when the plugin under development handles rule logic,
branching decisions, state management, or scoring systems. Board game mechanic design
and complex plugin logic share structural DNA: both require clear state definitions,
explicit transitions, and rules that survive edge cases without ambiguity.

**What changes in wordpress-studio as a result:**
- Rule-heavy plugin logic is reviewed through the lens of mechanic clarity: if the
  logic would confuse a playtester, it will confuse a developer extending the plugin
- State machine design in plugins (order states, post statuses, workflow steps) is
  tested against game design principles of clear phase transitions and reversibility

#### Inbound (boardgame-design-hydra > wordpress-studio)

**What boardgame-design-hydra sends back:**
- Mechanic balance logic: identifying feedback loops in plugin rule systems that
  could produce runaway leader problems or dominant strategies
- Branching rule clarity: the principle that every rule branch must have a defined
  resolution — applied to plugin conditional logic
- Player-state tracking patterns: how to model user progress, achievements, or
  sequential states cleanly
- Negative feedback loop design: how to build plugin systems that self-correct rather
  than amplify errors

**What changes in boardgame-design-hydra as a result of this link:**
- boardgame-design-hydra gains WordPress-specific implementation vocabulary: custom post
  types, meta fields, and transients as concrete implementation layers for abstract
  mechanic designs
- boardgame-design-hydra's rule-writing guidance gains a software clarity lens: rules
  that cannot be implemented cleanly in code are likely ambiguous rules

---

### Link 5: wordpress-studio <--> humanizer

#### Outbound (wordpress-studio > humanizer)

**What wordpress-studio sends:**
- Generated readme files for AI-pattern removal
- Generated admin notice copy for natural language review
- PHPDoc descriptions and parameter explanations for clarity review
- Any generated English prose in plugin output (error messages, success messages,
  email content, user-facing labels)

**Why it sends this:**
Code generation produces technically correct but often AI-patterned English prose as
a side effect. Plugin readme files, admin UI copy, and user-facing messages that read
as generated text undermine client trust and product quality. Humanizer removes the
patterns before the text ships.

**What changes in wordpress-studio as a result:**
- All generated English prose passes through humanizer before being presented as
  final output
- Inflated symbolism, promotional language, em-dash overuse, and rule-of-three
  constructions are treated as defects in WordPress documentation, not style choices

#### Inbound (humanizer > wordpress-studio)

**What humanizer sends back:**
- Cleaned prose with AI writing signatures removed
- Specific pattern flags: which sentences triggered which AI pattern detection rules
- Natural alternatives for technical jargon that was framed abstractly

**What changes in humanizer as a result of this link:**
- humanizer gains domain context: WordPress technical terms (hook, nonce, sanitise,
  escape, enqueue) are not AI jargon to remove — they are correct vocabulary to preserve
- humanizer's em-dash calibration rules are applied with a higher preservation
  threshold for technical documentation than for narrative prose

---

## Cross-Link Map

Beyond the primary star topology (wordpress-studio at centre), these cross-links exist
between linked skills themselves.

### Cross-Link A: professional-technical-writing <--> humanizer

**Direction:** professional-technical-writing sends structure; humanizer sends naturalness.

professional-technical-writing enforces: correct document structure, terminology
consistency, reader perspective, warning order.

humanizer enforces: absence of AI writing patterns, natural sentence rhythm, removal
of inflated language.

These are complementary. A document can pass both checks. A document that passes one
but fails the other is still defective. When both are active on the same text, apply
professional-technical-writing rules first (structure and clarity), then humanizer
(pattern removal).

### Cross-Link B: skill-creator <--> professional-technical-writing

**Direction:** skill-creator sends skill architecture; professional-technical-writing
sends documentation clarity.

Skill SKILL.md files are technical documents. They must meet professional-technical-writing
clarity standards. skill-creator ensures correct architecture. professional-technical-writing
ensures the instructions within that architecture are unambiguous.

When updating or creating any skill file, apply professional-technical-writing Module 2
(writing clearly and concisely) to the instruction body.

### Cross-Link C: alchemy-hive <--> professional-technical-writing

**Direction:** alchemy-hive sends content strategy; professional-technical-writing sends
copy clarity.

SEO content produced under alchemy-hive's Scout/Follower/Memory/Outlier framework must
also meet technical writing clarity standards when it is instructional content (how-to
guides, documentation pages, setup tutorials). alchemy-hive defines the intent;
professional-technical-writing ensures the execution.

---

## Audit Check

Before this file is considered complete, verify:

- [x] Every declared link has a matching reverse update section
- [x] Every affected skill has a clear, role-defined function in this network
- [x] No relationship is described only casually (all have explicit data contracts)
- [x] No placeholder sections remain
- [x] The logical flow is complete: data enters, is processed, is returned
- [x] All five primary links are bidirectional with explicit content definitions
- [x] All three cross-links are defined with direction and activation rules
- [x] Domain-specific vocabulary is preserved, not treated as jargon to remove
- [x] Feedback loops (positive and negative) are defined in main SKILL.md with operational mechanisms
- [x] The full instruction text has been provided without truncation
- [x] All reference files declared in SKILL.md Reference Guide table exist on disk (W22 fix: this check was previously marked complete while six files were absent — corrected in Audit Round 1)
- [x] SKILL.md and skill-network.md do not contain duplicate canonical data (W10 fix: SKILL.md now contains a summary; skill-network.md is the authoritative source)
