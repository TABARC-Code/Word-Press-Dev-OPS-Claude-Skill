# Gutenberg Blocks Reference

Author: TABARC-Code / Blackwood Studio
Load this for block development, block.json, dynamic blocks, Interactivity API, and FSE.

---

## Block Output Format

Block development has a distinct, non-negotiable output structure. Every custom block
requires all four of these components.

```
my-plugin/
└── blocks/
    └── my-block/
        ├── block.json         # Block metadata — controls editor registration
        ├── index.js           # Editor script (edit function + registration)
        ├── edit.js            # Editor UI component (optional split)
        ├── save.js            # Save function (static blocks only)
        ├── style.scss         # Shared styles (editor + frontend)
        ├── editor.scss        # Editor-only styles
        └── render.php         # Dynamic block server-side render
```

---

## block.json — v3 Schema

```json
{
    "$schema": "https://schemas.wp.org/trunk/block.json",
    "apiVersion": 3,
    "name": "my-plugin/my-block",
    "version": "1.0.0",
    "title": "My Block",
    "category": "text",
    "icon": "smiley",
    "description": "One sentence. What the block does.",
    "keywords": [ "keyword1", "keyword2" ],
    "textdomain": "my-plugin",
    "attributes": {
        "content": {
            "type":    "string",
            "source": "html",
            "selector": "p",
            "default": ""
        },
        "alignment": {
            "type":    "string",
            "default": "left",
            "enum":    [ "left", "center", "right" ]
        },
        "showTitle": {
            "type":    "boolean",
            "default": true
        }
    },
    "supports": {
        "html":            false,
        "align":           true,
        "color":           { "background": true, "text": true },
        "spacing":         { "margin": true, "padding": true },
        "typography":      { "fontSize": true, "lineHeight": true },
        "__experimentalBorder": { "radius": true, "width": true, "color": true }
    },
    "editorScript": "file:./index.js",
    "editorStyle":  "file:./editor.css",
    "style":        "file:./style.css",
    "render":       "file:./render.php",
    "viewScript":   "file:./view.js"
}
```

---

## PHP Block Registration

```php
<?php
/**
 * Registers all blocks found in the blocks/ directory.
 */
function my_plugin_register_blocks(): void {
    $blocks_dir = MY_PLUGIN_PATH . 'blocks/';

    foreach ( glob( $blocks_dir . '*/block.json' ) as $block_json ) {
        register_block_type( dirname( $block_json ) );
    }
}
add_action( 'init', 'my_plugin_register_blocks' );
```

---

## Static Block — index.js

```javascript
import { registerBlockType } from '@wordpress/blocks';
import { useBlockProps, RichText, AlignmentControl, BlockControls } from '@wordpress/block-editor';
import { __ } from '@wordpress/i18n';
import metadata from './block.json';

registerBlockType( metadata.name, {
    edit( { attributes, setAttributes } ) {
        const { content, alignment } = attributes;
        const blockProps = useBlockProps( {
            className: `has-text-align-${ alignment }`,
        } );

        return (
            <>
                <BlockControls>
                    <AlignmentControl
                        value={ alignment }
                        onChange={ ( newAlign ) => setAttributes( { alignment: newAlign } ) }
                    />
                </BlockControls>
                <div { ...blockProps }>
                    <RichText
                        tagName="p"
                        value={ content }
                        onChange={ ( newContent ) => setAttributes( { content: newContent } ) }
                        placeholder={ __( 'Enter content…', 'my-plugin' ) }
                    />
                </div>
            </>
        );
    },

    save( { attributes } ) {
        const { content, alignment } = attributes;
        const blockProps = useBlockProps.save( {
            className: `has-text-align-${ alignment }`,
        } );

        return (
            <div { ...blockProps }>
                <RichText.Content tagName="p" value={ content } />
            </div>
        );
    },
} );
```

---

## Dynamic Block — render.php

Dynamic blocks render server-side on each request. The save function returns null.

```php
<?php
/**
 * Renders the my-block block server-side.
 *
 * @param array  $attributes Block attributes.
 * @param string $content    Block inner content (empty for dynamic blocks).
 * @param object $block      Block instance.
 * @return string Rendered HTML.
 */

// All attributes are sanitised here — they come from the editor, but
// the editor is not a trusted surface for raw output.
$alignment = sanitize_key( $attributes['alignment'] ?? 'left' );
$show_title = (bool) ( $attributes['showTitle'] ?? true );

$wrapper_attributes = get_block_wrapper_attributes(
    [ 'class' => 'has-text-align-' . $alignment ]
);
?>
<div <?php echo $wrapper_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- get_block_wrapper_attributes is safe ?>>
    <?php if ( $show_title ) : ?>
        <h2><?php echo esc_html( get_the_title() ); ?></h2>
    <?php endif; ?>
</div>
```

---

## Block Patterns

```php
<?php
/**
 * Registers a block pattern.
 */
function my_plugin_register_patterns(): void {
    register_block_pattern(
        'my-plugin/my-pattern',
        [
            'title'       => __( 'My Pattern', 'my-plugin' ),
            'description' => __( 'Pattern description.', 'my-plugin' ),
            'categories'  => [ 'featured' ],
            'content'     => '<!-- wp:group {"layout":{"type":"constrained"}} -->'
                             . '<div class="wp-block-group">'
                             . '<!-- wp:paragraph -->'
                             . '<p>Pattern content here.</p>'
                             . '<!-- /wp:paragraph -->'
                             . '</div>'
                             . '<!-- /wp:group -->',
        ]
    );
}
add_action( 'init', 'my_plugin_register_patterns' );

/**
 * Registers a block pattern category.
 */
function my_plugin_register_pattern_categories(): void {
    register_block_pattern_category(
        'my-plugin',
        [ 'label' => __( 'My Plugin', 'my-plugin' ) ]
    );
}
add_action( 'init', 'my_plugin_register_pattern_categories' );
```

---

## Interactivity API (WordPress 6.5+)

The Interactivity API replaces bespoke JS for interactive blocks. Use it for
any client-side state that previously required custom JavaScript.

```javascript
// view.js — runs on the frontend
import { store, getContext } from '@wordpress/interactivity';

store( 'my-plugin/my-block', {
    actions: {
        toggle() {
            const context = getContext();
            context.isOpen = ! context.isOpen;
        },
    },
    callbacks: {
        logOpen() {
            const { isOpen } = getContext();
            // Side effects here — runs when isOpen changes.
        },
    },
} );
```

```php
<?php
// render.php — add data-wp-interactive and context
$wrapper_attributes = get_block_wrapper_attributes();
?>
<div
    <?php echo $wrapper_attributes; // phpcs:ignore ?>
    data-wp-interactive="my-plugin/my-block"
    <?php echo wp_interactivity_data_wp_context( [ 'isOpen' => false ] ); ?>
>
    <button data-wp-on--click="actions.toggle">
        <?php esc_html_e( 'Toggle', 'my-plugin' ); ?>
    </button>
    <div data-wp-bind--hidden="!context.isOpen">
        <?php esc_html_e( 'Revealed content.', 'my-plugin' ); ?>
    </div>
</div>
```

---

## InspectorControls — Block Settings Panel

```javascript
import { InspectorControls } from '@wordpress/block-editor';
import { PanelBody, PanelRow, ToggleControl, SelectControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

// Inside edit():
<InspectorControls>
    <PanelBody title={ __( 'Block Settings', 'my-plugin' ) } initialOpen={ true }>
        <PanelRow>
            <ToggleControl
                label={ __( 'Show Title', 'my-plugin' ) }
                checked={ showTitle }
                onChange={ ( value ) => setAttributes( { showTitle: value } ) }
            />
        </PanelRow>
        <PanelRow>
            <SelectControl
                label={ __( 'Style', 'my-plugin' ) }
                value={ style }
                options={ [
                    { value: 'default', label: __( 'Default', 'my-plugin' ) },
                    { value: 'featured', label: __( 'Featured', 'my-plugin' ) },
                ] }
                onChange={ ( value ) => setAttributes( { style: value } ) }
            />
        </PanelRow>
    </PanelBody>
</InspectorControls>
```

---


---

## Build Process

Gutenberg block JavaScript must be compiled. Without a build step, the browser
cannot run JSX or ES module imports.

**Standard setup using @wordpress/scripts:**

```bash
# In the plugin root
npm init -y
npm install --save-dev @wordpress/scripts
```

**package.json scripts (modern approach — WP 6.2+):**

Place blocks in `src/{block-name}/index.js`. Run without arguments — `@wordpress/scripts`
finds all blocks automatically via the `blocks` entry point convention.

```json
{
    "scripts": {
        "build":   "wp-scripts build",
        "start":   "wp-scripts start",
        "lint:js": "wp-scripts lint-js"
    }
}
```

**package.json scripts (explicit entry, older/single-block approach):**

```json
{
    "scripts": {
        "build":  "wp-scripts build blocks/my-block/index.js --output-path=blocks/my-block/build",
        "start":  "wp-scripts start blocks/my-block/index.js --output-path=blocks/my-block/build"
    }
}
```

The modern (no-argument) approach is preferred for new projects. It scales across
multiple blocks without modifying the build config.

**Update block.json to point to compiled output:**

```json
{
    "editorScript": "file:./build/index.js",
    "editorStyle":  "file:./build/index.css",
    "style":        "file:./build/style-index.css"
}
```

**Development workflow:**

```bash
npm run start    # Watch mode — recompiles on save
npm run build    # Production build — minified output
```

---

## Common Mistakes

| Mistake | Correct Approach |
|---|---|
| Outputting block attributes without escaping in render.php | Always `esc_html()`, `esc_attr()`, `esc_url()` in render.php |
| Using `save()` for dynamic blocks | Return `null` from `save()`, use `render.php` |
| Registering blocks in `plugins_loaded` | Register in `init` |
| Inlining styles via PHP echo | Use `style.css` / `editor.css` files in block.json |
| Using `wp.editor.InspectorControls` | Use `wp.blockEditor.InspectorControls` |
| Missing `apiVersion: 3` | Required for `useBlockProps` and modern API |
