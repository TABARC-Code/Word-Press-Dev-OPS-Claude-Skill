# REST API Reference

Author: TABARC-Code / Blackwood Studio
Load this for custom endpoints, authentication, schema design, and REST API security.

---

## Endpoint Registration

WordPress REST API namespace convention: use `vendor/v1` format where `vendor`
is your plugin slug. The `/v1` is part of the namespace string, not a separate
route segment — `my-plugin/v1` is one namespace.

```php
<?php
add_action( 'rest_api_init', 'my_plugin_register_routes' );

function my_plugin_register_routes(): void {
    $controller = new My_Plugin_REST_Controller();
    $controller->register_routes();
}
```

---

## Controller Class Pattern

Always use a controller class. Never register REST routes with raw `register_rest_route()`
calls outside a class — it makes versioning and permission management unmanageable.

```php
<?php
class My_Plugin_REST_Controller extends WP_REST_Controller {

    protected string    $namespace = 'my-plugin/v1';
    protected string    $rest_base = 'items';
    protected ?array    $schema    = null;  // Cached schema — required for get_item_schema() caching pattern

    public function register_routes(): void {
        // Collection endpoint: /wp-json/my-plugin/v1/items
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base,
            [
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_items' ],
                    'permission_callback' => [ $this, 'get_items_permissions_check' ],
                    'args'                => $this->get_collection_params(),
                ],
                [
                    'methods'             => WP_REST_Server::CREATABLE,
                    'callback'            => [ $this, 'create_item' ],
                    'permission_callback' => [ $this, 'create_item_permissions_check' ],
                    'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::CREATABLE ),
                ],
                'schema' => [ $this, 'get_public_item_schema' ],
            ]
        );

        // Single item endpoint: /wp-json/my-plugin/v1/items/{id}
        register_rest_route(
            $this->namespace,
            '/' . $this->rest_base . '/(?P<id>[\d]+)',
            [
                'args' => [
                    'id' => [
                        'description' => __( 'Unique identifier for the item.', 'my-plugin' ),
                        'type'        => 'integer',
                        'minimum'     => 1,
                    ],
                ],
                [
                    'methods'             => WP_REST_Server::READABLE,
                    'callback'            => [ $this, 'get_item' ],
                    'permission_callback' => [ $this, 'get_item_permissions_check' ],
                ],
                [
                    'methods'             => WP_REST_Server::EDITABLE,
                    'callback'            => [ $this, 'update_item' ],
                    'permission_callback' => [ $this, 'update_item_permissions_check' ],
                    'args'                => $this->get_endpoint_args_for_item_schema( WP_REST_Server::EDITABLE ),
                ],
                [
                    'methods'             => WP_REST_Server::DELETABLE,
                    'callback'            => [ $this, 'delete_item' ],
                    'permission_callback' => [ $this, 'delete_item_permissions_check' ],
                ],
                'schema' => [ $this, 'get_public_item_schema' ],
            ]
        );
    }

    // Permission callbacks — never return true for all requests
    public function get_items_permissions_check( WP_REST_Request $request ): bool|WP_Error {
        // Public read — still validate context
        return true;
    }

    public function create_item_permissions_check( WP_REST_Request $request ): bool|WP_Error {
        if ( ! current_user_can( 'edit_posts' ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You do not have permission to create items.', 'my-plugin' ),
                [ 'status' => rest_authorization_required_code() ]
            );
        }
        return true;
    }

    public function update_item_permissions_check( WP_REST_Request $request ): bool|WP_Error {
        $item = $this->get_item_by_id( $request->get_param( 'id' ) );
        if ( is_wp_error( $item ) ) {
            return $item;
        }
        if ( ! current_user_can( 'edit_post', $item->ID ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You do not have permission to edit this item.', 'my-plugin' ),
                [ 'status' => rest_authorization_required_code() ]
            );
        }
        return true;
    }

    public function delete_item_permissions_check( WP_REST_Request $request ): bool|WP_Error {
        if ( ! current_user_can( 'delete_posts' ) ) {
            return new WP_Error(
                'rest_forbidden',
                __( 'You do not have permission to delete items.', 'my-plugin' ),
                [ 'status' => rest_authorization_required_code() ]
            );
        }
        return true;
    }

    // Callbacks
    public function get_items( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $args = [
            'post_type'      => 'my_item',
            'posts_per_page' => (int) $request->get_param( 'per_page' ) ?: 10,
            'paged'          => (int) $request->get_param( 'page' ) ?: 1,
            'orderby'        => sanitize_key( $request->get_param( 'orderby' ) ?: 'date' ),
            'order'          => strtoupper( sanitize_key( $request->get_param( 'order' ) ?: 'DESC' ) ),
        ];

        $query = new WP_Query( $args );
        $items = [];

        foreach ( $query->posts as $post ) {
            $items[] = $this->prepare_item_for_response( $post, $request );
        }

        $response = rest_ensure_response( $items );
        $response->header( 'X-WP-Total', $query->found_posts );
        $response->header( 'X-WP-TotalPages', $query->max_num_pages );

        return $response;
    }

    public function create_item( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $prepared = $this->prepare_item_for_database( $request );

        if ( is_wp_error( $prepared ) ) {
            return $prepared;
        }

        $post_id = wp_insert_post( $prepared, true );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        $post = get_post( $post_id );
        $response = $this->prepare_item_for_response( $post, $request );
        $response->set_status( 201 );
        $response->header( 'Location', rest_url( $this->namespace . '/' . $this->rest_base . '/' . $post_id ) );

        return $response;
    }

    // Helper: fetch item by ID, returning WP_Error if not found
    private function get_item_by_id( int $id ): WP_Post|WP_Error {
        $post = get_post( $id );
        if ( ! $post || 'my_item' !== $post->post_type ) {
            return new WP_Error(
                'rest_item_not_found',
                __( 'Item not found.', 'my-plugin' ),
                [ 'status' => 404 ]
            );
        }
        return $post;
    }

    // Prepare item for database insert/update
    protected function prepare_item_for_database( WP_REST_Request $request ): array|WP_Error {
        $prepared = [];

        if ( isset( $request['title'] ) ) {
            $prepared['post_title'] = sanitize_text_field( $request['title'] );
        }

        if ( isset( $request['status'] ) ) {
            $allowed  = [ 'publish', 'draft', 'pending', 'private' ];
            $prepared['post_status'] = in_array( $request['status'], $allowed, true )
                ? $request['status']
                : 'draft';
        }

        $prepared['post_type'] = 'my_item';

        return $prepared;
    }

    // Prepare item for REST response
    public function prepare_item_for_response( WP_Post $item, WP_REST_Request $request ): WP_REST_Response {
        $data = [
            'id'     => $item->ID,
            'title'  => $item->post_title,
            'status' => $item->post_status,
            'link'   => get_permalink( $item->ID ),
        ];

        return rest_ensure_response( $data );
    }

    // Schema
    public function get_item_schema(): array {
        if ( $this->schema ) {
            return $this->add_additional_fields_schema( $this->schema );
        }

        $schema = [
            '$schema'    => 'http://json-schema.org/draft-04/schema#',
            'title'      => 'item',
            'type'       => 'object',
            'properties' => [
                'id' => [
                    'description' => __( 'Unique identifier for the item.', 'my-plugin' ),
                    'type'        => 'integer',
                    'context'     => [ 'view', 'edit' ],
                    'readonly'    => true,
                ],
                'title' => [
                    'description' => __( 'Title of the item.', 'my-plugin' ),
                    'type'        => 'string',
                    'context'     => [ 'view', 'edit' ],
                    'minLength'   => 1,
                ],
                'status' => [
                    'description' => __( 'Publication status.', 'my-plugin' ),
                    'type'        => 'string',
                    'enum'        => [ 'publish', 'draft', 'pending', 'private' ],
                    'context'     => [ 'view', 'edit' ],
                    'default'     => 'draft',
                ],
            ],
        ];

        $this->schema = $schema;
        return $this->add_additional_fields_schema( $this->schema );
    }
}
```

---

## Authentication Methods

### Cookie Authentication (Browser/AJAX)

Requires a nonce. Built into WordPress. No extra setup.

```javascript
// JavaScript — pass nonce with every request
fetch( '/wp-json/my-plugin/v1/items', {
    method:  'POST',
    headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce':   wpApiSettings.nonce,
    },
    body: JSON.stringify( { title: 'New Item' } ),
} );
```

### Application Passwords (WordPress 5.6+)

Generated in wp-admin > Users > Profile. Used for server-to-server communication.

```
Authorization: Basic base64( username:application_password )
```

### OAuth / JWT

Not built into WordPress core. Requires a plugin. Recommended for production APIs
serving mobile apps or third-party clients: `WP REST API — OAuth 1.0a Server` or
`JWT Authentication for WP REST API`.

---

## REST API Security Rules

These rules apply in addition to the main security.md rules.

1. **Never use `'permission_callback' => '__return_true'` on write endpoints.**
   This is acceptable for genuinely public reads only. Writes always require
   a capability check.

2. **Validate and sanitise all `WP_REST_Request` parameters explicitly.** Schema
   validation via `register_rest_route` args reduces this burden but does not eliminate it.

3. **Use `rest_authorization_required_code()`** rather than hardcoding 401 or 403.
   This function returns the correct code based on login state.

4. **Rate limiting.** WordPress core has none. For public APIs, implement transient-based
   rate limiting or use a caching layer (nginx, Cloudflare).

5. **Namespace versioning.** Always use `/v1` in your namespace. When breaking changes
   are needed, add `/v2` — never modify the existing version.

---

## WP_Error Pattern

Return `WP_Error` from REST callbacks for all error conditions. Never `wp_die()`.

```php
// Not found
return new WP_Error(
    'rest_item_not_found',
    __( 'Item not found.', 'my-plugin' ),
    [ 'status' => 404 ]
);

// Validation failure
return new WP_Error(
    'rest_invalid_param',
    __( 'Invalid parameter: title cannot be empty.', 'my-plugin' ),
    [ 'status' => 400 ]
);

// Server error
return new WP_Error(
    'rest_item_save_failed',
    __( 'Failed to save item.', 'my-plugin' ),
    [ 'status' => 500 ]
);
```
