# Documentation Standards Reference

Load this when producing user-facing text, readme files, admin copy, or PHPDoc.

This reference defines how the `wordpress-studio` to `professional-technical-writing`
link operates in practice. Standards here are derived from that skill's four modules
and adapted for WordPress-specific contexts.

---

## Inbound Contract from professional-technical-writing

This skill receives the following from `professional-technical-writing`:

- Module 1: Document structure (section order, heading hierarchy)
- Module 2: Clarity rules (active voice, reader perspective, redundancy elimination)
- Module 3: Layout (heading style, bullet formatting, punctuation)
- Module 4: Grammar corrections (comparisons, articles, passive/active)

Domain preservation rule: WordPress technical terms are not jargon to simplify.
The following terms are preserved as-is in all documentation:
`hook`, `nonce`, `sanitise`, `escape`, `enqueue`, `transient`, `capability`,
`filter`, `action`, `shortcode`, `template hierarchy`, `WP_Query`, `$wpdb`.

---

## readme.txt Structure

WordPress.org readme files follow a fixed structure. Apply Module 1 section order.

```
=== Plugin Name ===
Contributors: username
Tags: tag1, tag2
Requires at least: 6.4
Tested up to: {current WordPress latest at release — always update before shipping}
Stable tag: 1.0.0
Requires PHP: 8.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

One-sentence description. Plain English. No markup. Under 150 characters.

== Description ==

What the plugin does. Benefits to the user. No promotional language.
Write from the reader's perspective.

== Installation ==

1. Upload the plugin files to /wp-content/plugins/plugin-name.
2. Activate the plugin through the Plugins menu in WordPress.
3. Configure the settings under Settings > Plugin Name.

== Frequently Asked Questions ==

= Question in sentence form? =

Answer. Direct. No padding.

== Changelog ==

= 1.0.0 =
* Initial release.
```

**Module 2 rules applied to readmes:**
- No "This plugin allows you to..." — state what it does directly
- No "powerful", "robust", "seamless", "cutting-edge" — state the feature
- No "easy to use" — show what is simple, do not claim it
- Maximum one idea per sentence

---

## PHPDoc Standards

PHPDoc is developer-facing documentation. Apply Module 2 clarity rules with higher
tolerance for technical precision over brevity.

```php
/**
 * Retrieves all items belonging to a specific user.
 *
 * Queries the custom items table and returns an array of item objects.
 * Returns an empty array if no items are found or if the user does not exist.
 *
 * @since 1.0.0
 *
 * @param int    $user_id The ID of the WordPress user.
 * @param string $status  Optional. Item status to filter by. Default 'active'.
 *                        Accepts 'active', 'inactive', 'pending'.
 * @return array Array of item objects, empty array if none found.
 */
function my_plugin_get_user_items( int $user_id, string $status = 'active' ): array {
```

**Rules:**
- First line: one sentence, verb in third person singular, states what the function does
- Second paragraph: any important caveats (return edge cases, side effects)
- `@param`: type, name, description. For optional params: note "Optional." and default
- `@return`: type and content description. Document edge cases (empty array vs null)
- `@since`: always include version when the function was introduced
- No filler: "This function" is implied — do not open the docblock with it

---

## Admin Notice Copy

Admin notices are user-facing. Apply Module 2 reader-perspective rules strictly.

```php
// Wrong: passive, vague
__( 'The settings have been updated successfully.', 'my-plugin' )

// Right: direct, active
__( 'Settings saved.', 'my-plugin' )

// Wrong: promotional
__( 'Your plugin is now fully configured and ready to deliver amazing results!', 'my-plugin' )

// Right: functional
__( 'Plugin configured. Items will sync every 24 hours.', 'my-plugin' )

// Error messages: say what happened and what the user can do
// Wrong: technical dump
__( 'Error: 403 Forbidden — nonce verification failed.', 'my-plugin' )

// Right: user-facing explanation
__( 'The form could not be submitted. Reload the page and try again.', 'my-plugin' )
```

---

## Inline Code Comments

Inline comments explain the non-obvious. They do not describe what the code does —
the code does that. They explain why.

```php
// Wrong: describes the code
// Check if user is admin
if ( current_user_can( 'manage_options' ) ) {

// Right: explains the reason for the check
// Settings are site-wide; restrict to administrators only.
if ( current_user_can( 'manage_options' ) ) {

// Wrong: states the obvious
// Loop through results
foreach ( $results as $result ) {

// Right: explains a non-obvious decision
// Process in reverse to avoid re-indexing issues after deletion.
foreach ( array_reverse( $results ) as $result ) {
```

---

## Humanizer Handoff Rules

This section defines the *implementation detail* of the humanizer activation rule.
The activation *trigger* is defined in `SKILL.md` under Linked Skill Activation Rules.
If the two conflict, `SKILL.md` takes precedence.

Before any prose text is marked as final output, pass it through the `humanizer` skill
if any of the following patterns are present:

- Sentences opening with "This", "The", "Our"
- Rule of three constructions ("simple, powerful, and effective")
- Em-dash count exceeding one per paragraph
- Abstract promotional terms ("seamless", "robust", "powerful")
- Hedging language ("may", "might", "could", "should" in instructional contexts)
- Passive voice in instructional sentences

The humanizer will return cleaned prose. Apply its corrections directly.
