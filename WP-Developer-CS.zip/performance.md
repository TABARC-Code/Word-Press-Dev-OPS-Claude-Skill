# Performance Reference

Author: TABARC-Code / Blackwood Studio
Load this for caching, query optimisation, asset optimisation, and Core Web Vitals.

---

## Transients API

Transients cache expensive data with an expiry time. Use for external API responses,
complex queries, and any data that is expensive to compute and does not change per-request.

```php
<?php
/**
 * Retrieves expensive data with transient caching.
 *
 * @return array Data array, empty on failure.
 */
function my_plugin_get_expensive_data(): array {
    $cache_key = 'my_plugin_expensive_data';
    $cached = get_transient( $cache_key );

    if ( false !== $cached ) {
        return $cached;
    }

    // Expensive operation — may return empty array (valid) or false (failure).
    $data = my_plugin_compute_data();

    if ( false !== $data ) {
        // Cache both populated AND empty arrays — an empty result is a valid
        // result and should be cached to avoid repeat queries.
        // Only skip caching on explicit failure (false return).
        set_transient( $cache_key, $data, 12 * HOUR_IN_SECONDS );
    }

    return is_array( $data ) ? $data : [];
}

// Invalidate on relevant data change
add_action( 'save_post_my_item', 'my_plugin_invalidate_cache' );
function my_plugin_invalidate_cache( int $post_id ): void {
    delete_transient( 'my_plugin_expensive_data' );
}
```

### WordPress Time Constants

```php
MINUTE_IN_SECONDS  // 60
HOUR_IN_SECONDS    // 3600
DAY_IN_SECONDS     // 86400
WEEK_IN_SECONDS    // 604800
MONTH_IN_SECONDS   // 2592000 (30 days)
YEAR_IN_SECONDS    // 31536000
```

---

## Object Cache

Object cache stores data in memory for the current request. On supported hosts
(WP Engine, Kinsta, Redis-enabled setups), a persistent object cache stores data
across requests without needing transients.

```php
// wp_cache_* functions work identically to transients in API surface,
// but use the object cache backend if available
wp_cache_set( 'my_key', $data, 'my_group', HOUR_IN_SECONDS );
$data = wp_cache_get( 'my_key', 'my_group' );
wp_cache_delete( 'my_key', 'my_group' );

// Check if persistent cache is active
if ( wp_using_ext_object_cache() ) {
    // Persistent cache available — prefer wp_cache_* over transients
}
```

---

## WP_Query Optimisation

### What to Avoid

```php
// NEVER — query_posts() breaks the main query and is unreliable
query_posts( 'post_type=my_item&posts_per_page=10' );

// NEVER — no_found_rows defaults to false; disable it when pagination is not needed
$query = new WP_Query( [ 'post_type' => 'my_item' ] ); // runs expensive COUNT query

// AVOID — get_posts is fine but adds SQL_CALC_FOUND_ROWS if suppress_filters is false
$posts = get_posts( [ 'numberposts' => 10 ] );
```

### Optimised Query Patterns

```php
// Count rows only when pagination is needed — disable otherwise
$query = new WP_Query(
    [
        'post_type'              => 'my_item',
        'posts_per_page'         => 10,
        'no_found_rows'          => true,   // Skip COUNT query when not paginating
        'update_post_meta_cache' => false,  // Skip meta cache if not using post meta
        'update_post_term_cache' => false,  // Skip term cache if not displaying terms
        'fields'                 => 'ids',  // Return IDs only if objects not needed
    ]
);

// IDs-only query — use when you only need post IDs
$post_ids = get_posts(
    [
        'post_type'   => 'my_item',
        'numberposts' => -1,
        'fields'      => 'ids',
    ]
);

// Avoid meta queries in large datasets — they are slow
// SLOW:
$query = new WP_Query( [
    'meta_query' => [
        [ 'key' => '_my_flag', 'value' => '1' ],
    ],
] );
// FAST: Use a custom table with an index on the flag column instead
```

---

## Custom Database Queries vs WP_Query

Use direct `$wpdb` queries when:
- Joining multiple tables that `WP_Query` cannot express
- Working with custom tables
- Aggregation (SUM, COUNT, GROUP BY) is required
- The query is so complex that meta_query/tax_query would be unacceptably slow

```php
global $wpdb;

// Aggregation example — cannot use WP_Query
$totals = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT post_author, COUNT(*) as post_count
         FROM {$wpdb->posts}
         WHERE post_type = %s
           AND post_status = %s
         GROUP BY post_author
         ORDER BY post_count DESC
         LIMIT %d",
        'my_item',
        'publish',
        10
    )
);
```

---

## Conditional Asset Loading

Never load assets globally. Load only where needed.

```php
<?php
add_action( 'wp_enqueue_scripts', 'my_plugin_conditional_enqueue' );

function my_plugin_conditional_enqueue(): void {
    // Only on single posts of this type
    if ( is_singular( 'my_item' ) ) {
        wp_enqueue_style( 'my-plugin-single', MY_PLUGIN_URL . 'assets/css/single.css', [], MY_PLUGIN_VERSION );
        wp_enqueue_script( 'my-plugin-single', MY_PLUGIN_URL . 'assets/js/single.js', [], MY_PLUGIN_VERSION, true );
    }

    // Only on specific page template
    if ( is_page_template( 'templates/my-template.php' ) ) {
        wp_enqueue_style( 'my-plugin-template', MY_PLUGIN_URL . 'assets/css/template.css', [], MY_PLUGIN_VERSION );
    }
}

// Admin assets — target specific screen
add_action( 'admin_enqueue_scripts', 'my_plugin_admin_enqueue' );

function my_plugin_admin_enqueue( string $hook_suffix ): void {
    // Only on this plugin's settings page
    if ( 'settings_page_my-plugin' !== $hook_suffix ) {
        return;
    }

    wp_enqueue_style( 'my-plugin-admin', MY_PLUGIN_URL . 'assets/css/admin.css', [], MY_PLUGIN_VERSION );
    wp_enqueue_script( 'my-plugin-admin', MY_PLUGIN_URL . 'assets/js/admin.js', [ 'jquery' ], MY_PLUGIN_VERSION, true );
}
```

---

## Asset Versioning and Cache-Busting

```php
// Development: use filemtime() for automatic cache busting
$version = WP_DEBUG ? filemtime( MY_PLUGIN_PATH . 'assets/css/main.css' ) : MY_PLUGIN_VERSION;
wp_enqueue_style( 'my-plugin-main', MY_PLUGIN_URL . 'assets/css/main.css', [], $version );

// Production: use plugin version constant
wp_enqueue_style( 'my-plugin-main', MY_PLUGIN_URL . 'assets/css/main.css', [], MY_PLUGIN_VERSION );
```

---

## Core Web Vitals — WordPress Context

| Metric | WordPress Cause | Fix |
|---|---|---|
| LCP slow | Unoptimised hero image, render-blocking CSS | `loading="eager"` on LCP image, `fetchpriority="high"`, preload link |
| CLS | Images without dimensions, injected content above fold | Always set width/height on `wp_get_attachment_image()`, avoid top banners |
| INP slow | Heavy JS on interaction | Defer non-critical JS, use `wp_add_inline_script` sparingly |
| FID (legacy) | Parser-blocking scripts | Load all scripts in footer, use `defer` or `async` where safe |

```php
// Add loading and fetchpriority to hero image
add_filter( 'wp_get_attachment_image_attributes', 'my_hero_image_attrs', 10, 3 );
function my_hero_image_attrs( array $attr, WP_Post $attachment, $size ): array {
    if ( 'hero' === $size ) {
        $attr['fetchpriority'] = 'high';
        $attr['loading']       = 'eager';
    }
    return $attr;
}
```

---

## Scheduled Tasks — Action Scheduler vs wp-cron

`wp-cron` is not a real cron — it fires on page load. For high-volume or reliable
scheduled tasks, use Action Scheduler (bundled with WooCommerce; installable standalone).

```php
// wp-cron — simple, unreliable on low-traffic sites
add_action( 'my_plugin_hourly_event', 'my_plugin_hourly_callback' );
if ( ! wp_next_scheduled( 'my_plugin_hourly_event' ) ) {
    wp_schedule_event( time(), 'hourly', 'my_plugin_hourly_event' );
}
// Clear on deactivation
register_deactivation_hook( __FILE__, function(): void {
    wp_clear_scheduled_hook( 'my_plugin_hourly_event' );
} );

// Action Scheduler — reliable, queue-based, WooCommerce-bundled
if ( function_exists( 'as_schedule_recurring_action' ) ) {
    // Action Scheduler available (WooCommerce active, or standalone install).
    if ( ! as_has_scheduled_action( 'my_plugin_daily_action', [], 'my-plugin' ) ) {
        as_schedule_recurring_action(
            strtotime( 'tomorrow midnight' ),
            DAY_IN_SECONDS,
            'my_plugin_daily_action',
            [],
            'my-plugin'
        );
    }
} else {
    // Fallback: standard wp-cron if Action Scheduler unavailable.
    if ( ! wp_next_scheduled( 'my_plugin_daily_event' ) ) {
        wp_schedule_event( time(), 'daily', 'my_plugin_daily_event' );
    }
    add_action( 'my_plugin_daily_event', 'my_plugin_daily_callback' );
}
add_action( 'my_plugin_daily_action', 'my_plugin_daily_callback' );
```
