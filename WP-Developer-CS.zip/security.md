# Security Reference

Load this for any security question, code review, or capability check implementation.

---

## Sanitisation Functions — Input Layer

**Rule zero: always call `wp_unslash()` before sanitising any superglobal value.**
WordPress adds slashes to `$_GET`, `$_POST`, `$_REQUEST`, `$_COOKIE` on arrival.
Without `wp_unslash()`, sanitisation functions receive escaped data and produce
incorrect results. This is a WPCS hard requirement, not optional.

```php
// Wrong — missing wp_unslash()
$value = sanitize_text_field( $_POST['my_field'] );

// Correct
$value = sanitize_text_field( wp_unslash( $_POST['my_field'] ) );

// With isset check (standard pattern):
$value = isset( $_POST['my_field'] )
    ? sanitize_text_field( wp_unslash( $_POST['my_field'] ) )
    : '';
```

Use the narrowest function that fits. Never sanitise with a broader function when a
narrower one exists.

| Context | Function |
|---|---|
| Plain text (no HTML) | `sanitize_text_field()` |
| Textarea (multiline plain text) | `sanitize_textarea_field()` |
| Email address | `sanitize_email()` |
| URL | `esc_url_raw()` (for storage), `esc_url()` (for output) |
| Integer | `absint()` or `intval()` |
| Float | `floatval()` |
| Filename | `sanitize_file_name()` |
| HTML class | `sanitize_html_class()` |
| Key/slug | `sanitize_key()` |
| Post title | `sanitize_text_field()` |
| HTML (allowed tags) | `wp_kses()` or `wp_kses_post()` |
| SQL input | Never sanitise — use `$wpdb->prepare()` |

---

## Escaping Functions — Output Layer

Escape at the point of output, not at the point of storage.

```php
// HTML content
echo esc_html( $user_data );

// HTML attribute values
echo '<input value="' . esc_attr( $value ) . '">';

// URLs in href/src attributes
echo '<a href="' . esc_url( $url ) . '">';

// JavaScript strings
echo '<script>var x = "' . esc_js( $value ) . '";</script>';

// Raw HTML with allowed tags (admin use only)
echo wp_kses_post( $content );

// Translated strings (automatically safe for display)
echo esc_html__( 'Submit', 'my-plugin' );

// wp_kses with custom allowed tags
$allowed = [
    'a'      => [ 'href' => [], 'title' => [] ],
    'strong' => [],
    'em'     => [],
];
echo wp_kses( $content, $allowed );
```

---

## Nonce Patterns

Nonces protect against CSRF. They expire. Always verify before processing.

```php
// Form: add to output
wp_nonce_field( 'my_plugin_save_action', 'my_plugin_nonce' );

// Form: verify on submission
if ( ! isset( $_POST['my_plugin_nonce'] ) ||
     ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['my_plugin_nonce'] ) ), 'my_plugin_save_action' ) ) {
    wp_die( esc_html__( 'Security check failed.', 'my-plugin' ) );
}

// AJAX: generate nonce for JS
wp_localize_script( 'my-script', 'myData', [
    'nonce' => wp_create_nonce( 'my_ajax_nonce' ),
] );

// AJAX: verify in handler
// check_ajax_referer() handles wp_unslash() internally — no manual unslash needed here.
add_action( 'wp_ajax_my_action', 'my_ajax_handler' );
function my_ajax_handler(): void {
    check_ajax_referer( 'my_ajax_nonce', 'nonce' );
    // All subsequent $_POST/$_GET reads still need wp_unslash() + sanitise.
}

// REST: nonce in header (JS)
// fetch( url, { headers: { 'X-WP-Nonce': wpApiSettings.nonce } } )
```

---

## Capability Checks

Never skip. Apply the minimum required capability.
Context matters: `wp_die()` is correct for admin pages. REST callbacks must
return `WP_Error`. AJAX handlers must use `wp_send_json_error()`. See the
error routing table in `SKILL.md` — Error Handling section.

```php
// Admin page context — wp_die() is correct here
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'You do not have permission to do this.', 'my-plugin' ) );
}

// Custom capability (register with map_meta_cap)
if ( ! current_user_can( 'edit_my_item', $post_id ) ) {
    return;
}

// REST endpoint permission callback
'permission_callback' => function(): bool {
    return current_user_can( 'edit_posts' );
},

// In AJAX: combine with nonce
add_action( 'wp_ajax_my_action', function(): void {
    check_ajax_referer( 'my_nonce', 'nonce' );
    if ( ! current_user_can( 'edit_posts' ) ) {
        wp_send_json_error( [ 'message' => __( 'Permission denied.', 'my-plugin' ) ] );
    }
    // Process
} );
```

---

## Database — Prepared Statements

Every query that includes variable data must use `$wpdb->prepare()`. No exceptions.

```php
global $wpdb;

// SELECT with WHERE
$results = $wpdb->get_results(
    $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}my_table WHERE user_id = %d AND status = %s",
        $user_id,
        $status
    )
);

// INSERT
$wpdb->insert(
    $wpdb->prefix . 'my_table',
    [
        'user_id' => $user_id,
        'data'    => $data,
    ],
    [ '%d', '%s' ]
);

// UPDATE
$wpdb->update(
    $wpdb->prefix . 'my_table',
    [ 'status' => $new_status ],
    [ 'id' => $record_id ],
    [ '%s' ],
    [ '%d' ]
);

// DELETE
$wpdb->delete(
    $wpdb->prefix . 'my_table',
    [ 'id' => $record_id ],
    [ '%d' ]
);

// Type placeholders: %d (integer), %f (float), %s (string)
// Never use %s for integers — use %d
```

---

## File Upload Security

```php
function my_plugin_handle_upload( array $file ): array|WP_Error {
    // Whitelist allowed MIME types
    $allowed_types = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'application/pdf',
    ];

    // Use WordPress upload handler — never move files manually
    $overrides = [ 'test_form' => false ];
    $uploaded  = wp_handle_upload( $file, $overrides );

    if ( isset( $uploaded['error'] ) ) {
        return new WP_Error( 'upload_error', $uploaded['error'] );
    }

    // Verify MIME type after upload (not just file extension)
    $mime = wp_check_filetype( $uploaded['file'] );
    if ( ! in_array( $mime['type'], $allowed_types, true ) ) {
        // Use wp_delete_file() — never bare unlink().
        // wp_delete_file() validates the path is within the uploads directory
        // before deletion, preventing path traversal via crafted filenames.
        wp_delete_file( $uploaded['file'] );
        return new WP_Error( 'invalid_type', __( 'File type not allowed.', 'my-plugin' ) );
    }

    return $uploaded;
}
```

---

## REST API Authentication — Minimum Rules

Full REST patterns are in `references/rest-api.md`. These rules apply here as
security constraints.

1. Never use `'permission_callback' => '__return_true'` on write endpoints.
2. Always return `WP_Error` with `rest_authorization_required_code()` on auth failure.
3. Browser requests: nonce in `X-WP-Nonce` header. Generate with
   `wp_create_nonce( 'wp_rest' )` (or `wp_rest_nonce()` alias added WP 5.2+).
4. Server-to-server: Application Passwords (WP 5.6+). Never Basic Auth with main credentials.
5. Public read endpoints: still validate context and rate limit where appropriate.

---

## Direct File Access Prevention

Every PHP file that is not the main plugin entry point must include this:

```php
defined( 'ABSPATH' ) || exit;
```

Place this as the first line after the opening `<?php` tag.

---

## OWASP Top 10 Mapping (WordPress Context)

| OWASP | WordPress Mitigation |
|---|---|
| A01 Broken Access Control | `current_user_can()`, REST permission callbacks, nonces |
| A02 Cryptographic Failures | Never store passwords manually. Use `wp_set_password()` to set, `wp_check_password()` to verify. Never call `wp_hash_password()` directly — let WordPress handle the full flow. |
| A03 Injection (SQL) | `$wpdb->prepare()` always |
| A03 Injection (XSS) | All output escaped with correct `esc_*` function |
| A04 Insecure Design | Principle of least privilege; minimal capabilities |
| A05 Security Misconfiguration | `ABSPATH` checks; no debug in production; `.htaccess` rules |
| A06 Vulnerable Components | Keep WordPress, themes, plugins updated |
| A07 Auth Failures | Use WordPress auth functions; never roll your own |
| A08 Software Integrity | Verify plugin/theme sources; use checksums |
| A09 Logging | Do NOT rely on WP_DEBUG_LOG in production — it writes to a file that may be web-accessible by default. Use `error_log()` pointing to a log file outside the web root, or a dedicated logging library. Log security events (auth failures, permission violations) with enough context to audit. |
| A10 SSRF | Validate all URLs before `wp_remote_get()`; block private ranges |
