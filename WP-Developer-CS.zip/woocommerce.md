# WooCommerce Reference

Author: TABARC-Code / Blackwood Studio
Load this for WooCommerce hooks, HPOS, product/order API, payment gateways,
Cart/Checkout blocks, and subscription handling.

---

## WooCommerce 8.x Critical Changes

Two breaking architecture changes landed in WooCommerce 8.x. Know both.

**HPOS (High-Performance Order Storage) — WC 7.1+, default from 8.2**
Orders are now stored in custom tables (`wc_orders`, `wc_order_items`, etc.) rather
than WordPress `wp_posts`. Direct `get_post_meta()` on order IDs no longer works when
HPOS is active. Use the Orders API.

**Cart and Checkout Blocks — WC 8.3+**
The new Cart and Checkout blocks use a different hook system to the legacy shortcode
`[woocommerce_checkout]`. Classic action hooks like `woocommerce_before_checkout_form`
do not fire in the block checkout. Use the WooCommerce Store API and Block hooks instead.

---

## HPOS — Orders API

```php
<?php
// WRONG — breaks with HPOS active
$order_id = 42;
$status   = get_post_meta( $order_id, '_order_status', true );
$total    = get_post_meta( $order_id, '_order_total', true );

// CORRECT — works with both HPOS and legacy storage
$order = wc_get_order( $order_id );

if ( ! $order instanceof WC_Order ) {
    return;
}

$status  = $order->get_status();
$total   = $order->get_total();
$email   = $order->get_billing_email();
$items   = $order->get_items();

// Update order data
$order->update_status( 'processing', __( 'Updated by my plugin.', 'my-plugin' ) );
$order->add_meta_data( '_my_plugin_meta', $value, true );
$order->save();

// Query orders — HPOS compatible
$orders = wc_get_orders(
    [
        'limit'    => 20,
        'status'   => 'processing',
        'customer' => $user_id,
        'orderby'  => 'date',
        'order'    => 'DESC',
    ]
);
```

---

## Product API

```php
<?php
// Get a product
$product = wc_get_product( $product_id );

if ( ! $product instanceof WC_Product ) {
    return;
}

// Product data
$name        = $product->get_name();
$price       = $product->get_price();
$stock       = $product->get_stock_quantity();
$type        = $product->get_type(); // simple, variable, grouped, external

// Variable product — get variations
if ( $product instanceof WC_Product_Variable ) {
    $variations = $product->get_available_variations();
    foreach ( $variations as $variation ) {
        $variation_obj = wc_get_product( $variation['variation_id'] );
    }
}

// Update product
$product->set_price( '29.99' );
$product->set_stock_quantity( 100 );
$product->set_stock_status( 'instock' );
$product->save();
```

---

## Essential WooCommerce Hooks

### Product Page

```php
// Before product summary
add_action( 'woocommerce_before_single_product_summary', 'my_before_summary', 5 );

// Inside product summary (default hooks: title=5, rating=10, price=10, excerpt=20, add_to_cart=30, meta=40, sharing=50)
add_action( 'woocommerce_single_product_summary', 'my_summary_content', 25 );

// After add to cart button
add_action( 'woocommerce_after_add_to_cart_button', 'my_after_button' );
```

### Cart

```php
// Add a fee (e.g. handling charge)
add_action( 'woocommerce_cart_calculate_fees', 'my_add_cart_fee' );
function my_add_cart_fee( WC_Cart $cart ): void {
    if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
        return;
    }
    $cart->add_fee( __( 'Handling', 'my-plugin' ), 2.50, true );
}

// Modify cart item data
add_filter( 'woocommerce_cart_item_name', 'my_cart_item_name', 10, 3 );
function my_cart_item_name( string $name, array $cart_item, string $cart_item_key ): string {
    // Return modified or original $name
    return $name;
}
```

### Checkout (Classic Shortcode)

```php
// Add a custom checkout field
add_filter( 'woocommerce_checkout_fields', 'my_add_checkout_field' );
function my_add_checkout_field( array $fields ): array {
    $fields['order']['my_custom_field'] = [
        'type'        => 'text',
        'label'       => __( 'Custom Field', 'my-plugin' ),
        'placeholder' => __( 'Enter value', 'my-plugin' ),
        'required'    => false,
        'class'       => [ 'form-row-wide' ],
        'priority'    => 120,
    ];
    return $fields;
}

// Save custom checkout field
add_action( 'woocommerce_checkout_update_order_meta', 'my_save_checkout_field' );
function my_save_checkout_field( int $order_id ): void {
    if ( ! empty( $_POST['my_custom_field'] ) ) {
        $order = wc_get_order( $order_id );
        $order->update_meta_data(
            '_my_custom_field',
            sanitize_text_field( wp_unslash( $_POST['my_custom_field'] ) )
        );
        $order->save();
    }
}
```

### Order Processing

```php
// Fires when order status changes
add_action( 'woocommerce_order_status_changed', 'my_order_status_changed', 10, 4 );
function my_order_status_changed( int $order_id, string $old_status, string $new_status, WC_Order $order ): void {
    if ( 'completed' === $new_status ) {
        // Order just completed — run fulfilment logic
    }
}

// Fires after order is placed
add_action( 'woocommerce_thankyou', 'my_thankyou_handler', 10, 1 );
function my_thankyou_handler( int $order_id ): void {
    $order = wc_get_order( $order_id );
    if ( ! $order ) {
        return;
    }
    // Post-purchase actions
}
```

---

## Custom Payment Gateway

```php
<?php
/**
 * Registers a custom payment gateway.
 */
add_filter( 'woocommerce_payment_gateways', 'my_add_gateway' );
function my_add_gateway( array $gateways ): array {
    $gateways[] = 'My_Payment_Gateway';
    return $gateways;
}

class My_Payment_Gateway extends WC_Payment_Gateway {

    public function __construct() {
        $this->id                 = 'my_gateway';
        $this->icon               = '';
        $this->has_fields         = false;
        $this->method_title       = __( 'My Gateway', 'my-plugin' );
        $this->method_description = __( 'Pay via My Gateway.', 'my-plugin' );
        $this->supports           = [ 'products' ];

        $this->init_form_fields();
        $this->init_settings();

        $this->title       = $this->get_option( 'title' );
        $this->description = $this->get_option( 'description' );
        $this->enabled     = $this->get_option( 'enabled' );

        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, [ $this, 'process_admin_options' ] );
    }

    public function init_form_fields(): void {
        $this->form_fields = [
            'enabled' => [
                'title'   => __( 'Enable/Disable', 'my-plugin' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable My Gateway', 'my-plugin' ),
                'default' => 'yes',
            ],
            'title' => [
                'title'       => __( 'Title', 'my-plugin' ),
                'type'        => 'text',
                'description' => __( 'Shown at checkout.', 'my-plugin' ),
                'default'     => __( 'My Gateway', 'my-plugin' ),
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ];
    }

    /**
     * Processes and completes a payment.
     *
     * @param int $order_id Order ID.
     * @return array Result array with 'result' and 'redirect' keys.
     */
    public function process_payment( int $order_id ): array {
        $order = wc_get_order( $order_id );

        // --- Payment processing logic here ---

        // On success:
        $order->payment_complete();
        $order->reduce_order_stock();
        WC()->cart->empty_cart();

        return [
            'result'   => 'success',
            'redirect' => $this->get_return_url( $order ),
        ];
    }
}
```

---

## WooCommerce Block Checkout — Integration

Classic shortcode hooks do NOT fire in the block checkout. For block checkout
integration, use WooCommerce's Store API with block extensions.

```php
<?php
// Register a Store API extension (WC 6.5+)
add_action( 'woocommerce_blocks_loaded', 'my_plugin_register_store_api_extension' );
function my_plugin_register_store_api_extension(): void {
    if ( ! function_exists( 'woocommerce_store_api_register_endpoint_data' ) ) {
        return;
    }
    woocommerce_store_api_register_endpoint_data(
        [
            'endpoint'        => Automattic\WooCommerce\StoreApi\Schemas\V1\CartSchema::IDENTIFIER,
            'namespace'       => 'my-plugin',
            'data_callback'   => 'my_plugin_cart_data_callback',
            'schema_callback' => 'my_plugin_cart_schema_callback',
            'schema_type'     => ARRAY_A,
        ]
    );
}

function my_plugin_cart_data_callback(): array {
    return [
        'my_field' => get_option( 'my_plugin_setting', '' ),
    ];
}

function my_plugin_cart_schema_callback(): array {
    return [
        'my_field' => [
            'description' => __( 'My plugin field.', 'my-plugin' ),
            'type'        => 'string',
            'context'     => [ 'view', 'edit' ],
            'readonly'    => true,
        ],
    ];
}
```

---

## HPOS Compatibility Declaration

Plugins must declare HPOS compatibility. Without this, WooCommerce may disable HPOS
or show compatibility warnings.

```php
add_action( 'before_woocommerce_init', 'my_plugin_declare_hpos_compatibility' );
function my_plugin_declare_hpos_compatibility(): void {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,
            true  // true = compatible, false = incompatible
        );
    }
}
```

---

## WooCommerce Subscriptions — Scope Note

WooCommerce Subscriptions (WooCommerce.com commercial plugin) adds subscription
product types, recurring billing, and a distinct hook surface including:
`woocommerce_subscription_status_changed`, `wcs_get_subscription`, and the
`WC_Subscription` object which extends `WC_Order`.

This reference does not cover Subscriptions in detail. The plugin's documentation
is the authoritative source:
https://woocommerce.com/document/subscriptions/develop/

Key rules when working with Subscriptions:
- Always check `class_exists( 'WC_Subscriptions' )` before using Subscriptions APIs
- Never assume subscription renewal orders are standard WC_Order objects without checking
- HPOS compatibility must be declared separately for Subscriptions if the plugin
  interacts with subscription orders: use `FeaturesUtil::declare_compatibility()`
  with the appropriate feature key (verify key name with current Subscriptions plugin documentation — it varies by Subscriptions version)
