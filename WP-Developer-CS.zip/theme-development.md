# Theme Development Reference

Author: TABARC-Code / Blackwood Studio
Load this for theme files, template hierarchy, child themes, and Full Site Editing.

---

## Template Hierarchy — Classic Themes

WordPress resolves templates in priority order. The first match wins.

```
Single post:    single-{post-type}-{slug}.php
                single-{post-type}.php
                single.php
                singular.php
                index.php

Archive:        archive-{post-type}.php
                archive.php
                index.php

Taxonomy:       taxonomy-{taxonomy}-{term}.php
                taxonomy-{taxonomy}.php
                taxonomy.php
                archive.php
                index.php

Page:           {page-slug}.php
                page-{id}.php
                page.php
                singular.php
                index.php

Home/Blog:      home.php
                index.php

Front page:     front-page.php
                home.php (if static front page not set)
                index.php

404:            404.php
                index.php

Search:         search.php
                index.php
```

---

## Theme File Structure — Classic

```
my-theme/
├── style.css                  # Theme header — required
├── index.php                  # Fallback template — required
├── functions.php              # Theme setup, enqueues, features
├── header.php
├── footer.php
├── sidebar.php
├── single.php
├── page.php
├── archive.php
├── search.php
├── 404.php
├── comments.php
├── screenshot.png             # 1200x900px, shows in theme switcher
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
├── template-parts/
│   ├── content.php
│   ├── content-none.php
│   └── content-search.php
└── languages/
    └── my-theme.pot
```

---

## style.css Theme Header

```css
/*
Theme Name:   My Theme
Theme URI:    https://example.com/my-theme
Author:       TABARC-Code
Author URI:   https://example.com
Description:  Theme description. Plain text only.
Version:      1.0.0
Requires at least: 6.4
Tested up to: 6.7
Requires PHP: 8.1
License:      GNU General Public License v2 or later
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  my-theme
Tags:         tag1, tag2
*/
```

---

## functions.php — Theme Setup Pattern

```php
<?php
defined( 'ABSPATH' ) || exit;

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function my_theme_setup(): void {
    // Make theme available for translation.
    load_theme_textdomain( 'my-theme', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title.
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails.
    add_theme_support( 'post-thumbnails' );

    // Register navigation menus.
    register_nav_menus(
        [
            'primary' => esc_html__( 'Primary Menu', 'my-theme' ),
            'footer'  => esc_html__( 'Footer Menu', 'my-theme' ),
        ]
    );

    // Switch default core markup to output valid HTML5.
    add_theme_support(
        'html5',
        [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ]
    );

    // Add theme support for selective refresh for widgets.
    add_theme_support( 'customize-selective-refresh-widgets' );

    // Add support for editor styles.
    add_theme_support( 'editor-styles' );
    add_editor_style( 'assets/css/editor-style.css' );

    // Add support for responsive embeds.
    add_theme_support( 'responsive-embeds' );
}
add_action( 'after_setup_theme', 'my_theme_setup' );

/**
 * Enqueues scripts and styles.
 */
function my_theme_scripts(): void {
    wp_enqueue_style(
        'my-theme-style',
        get_stylesheet_uri(),
        [],
        wp_get_theme()->get( 'Version' )
    );

    wp_enqueue_style(
        'my-theme-main',
        get_template_directory_uri() . '/assets/css/main.css',
        [],
        wp_get_theme()->get( 'Version' )
    );

    wp_enqueue_script(
        'my-theme-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        wp_get_theme()->get( 'Version' ),
        true
    );

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'my_theme_scripts' );
```

---

## Child Theme

```css
/* style.css */
/*
Theme Name:   My Child Theme
Template:     parent-theme-slug
Version:      1.0.0
Text Domain:  my-child-theme
*/
```

```php
<?php
/* functions.php */
defined( 'ABSPATH' ) || exit;

/**
 * Enqueues parent and child theme styles in the correct order.
 */
function my_child_theme_enqueue_styles(): void {
    $parent_style = 'parent-theme-style';

    wp_enqueue_style(
        $parent_style,
        get_template_directory_uri() . '/style.css',
        [],
        wp_get_theme()->parent()->get( 'Version' )
    );

    wp_enqueue_style(
        'child-theme-style',
        get_stylesheet_directory_uri() . '/style.css',
        [ $parent_style ],
        wp_get_theme()->get( 'Version' )
    );
}
add_action( 'wp_enqueue_scripts', 'my_child_theme_enqueue_styles' );
```

---

## Full Site Editing (FSE) — Block Themes

### File Structure

```
my-block-theme/
├── style.css                  # Theme header (same format, no CSS needed)
├── index.html                 # Root template — required
├── functions.php              # theme.json still needs PHP support setup
├── theme.json                 # Design tokens, typography, spacing, colours
├── screenshot.png
├── parts/
│   ├── header.html
│   └── footer.html
├── patterns/
│   └── my-pattern.php
├── templates/
│   ├── single.html
│   ├── archive.html
│   ├── page.html
│   ├── search.html
│   └── 404.html
└── languages/
```

### theme.json Skeleton

```json
{
    "$schema": "https://schemas.wp.org/trunk/theme.json",
    "version": 3,
    "settings": {
        "color": {
            "palette": [
                {
                    "slug": "primary",
                    "color": "#1a1a2e",
                    "name": "Primary"
                },
                {
                    "slug": "secondary",
                    "color": "#e94560",
                    "name": "Secondary"
                }
            ]
        },
        "typography": {
            "fontFamilies": [
                {
                    "fontFamily": "'IBM Plex Mono', monospace",
                    "slug": "mono",
                    "name": "Monospace"
                }
            ],
            "fontSizes": [
                { "slug": "small",   "size": "0.875rem", "name": "Small"  },
                { "slug": "medium",  "size": "1rem",     "name": "Medium" },
                { "slug": "large",   "size": "1.25rem",  "name": "Large"  },
                { "slug": "x-large", "size": "1.5rem",   "name": "X-Large"}
            ]
        },
        "spacing": {
            "spacingScale": {
                "operator": "*",
                "increment": 1.5,
                "steps": 7,
                "mediumStep": 1.5,
                "unit": "rem"
            }
        },
        "layout": {
            "contentSize": "720px",
            "wideSize":    "1200px"
        }
    },
    "styles": {
        "color": {
            "background": "var(--wp--preset--color--primary)",
            "text":        "var(--wp--preset--color--secondary)"
        }
    }
}
```

---

## Classic vs FSE — Decision Guide

| Condition | Use |
|---|---|
| Client uses page builder (Elementor, Divi, WPBakery) | Classic theme |
| Project needs full Gutenberg editing of headers/footers | FSE block theme |
| Child theme of existing classic theme | Classic child theme |
| New build, WordPress 6.4+, no page builder dependency | FSE block theme |
| Complex custom post type templates | Either — FSE handles this via templates/ |
| WooCommerce store with Cart/Checkout blocks | FSE preferred (WC 8.3+) |

---

## Template Parts — Classic

```php
<?php
// In single.php:
get_template_part( 'template-parts/content', get_post_type() );

// Creates:  template-parts/content-{post-type}.php fallback to content.php
// NEVER use include/require for template parts — always get_template_part()
```

---

## Common Theme Hooks

```php
// wp_head() — outputs in <head>. Never bypass with direct echo.
add_action( 'wp_head', 'my_theme_custom_head_output' );

// wp_footer() — before </body>. Use for deferred scripts.
add_action( 'wp_footer', 'my_theme_footer_scripts' );

// body_class filter — adds classes to <body>.
add_filter( 'body_class', 'my_theme_body_classes' );

// the_content filter — processes post content.
// Use with care: runs on every get_the_content() call.
add_filter( 'the_content', 'my_theme_content_filter' );
```
