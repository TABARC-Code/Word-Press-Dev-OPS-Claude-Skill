# Hooks and Filters Reference

Author: TABARC-Code / Blackwood Studio
Load this when registering or using actions/filters, setting hook priorities, or
designing extension points for downstream developers.

---

## Core Concepts

**Action:** Fires at a specific point. Code runs. Nothing returned.
**Filter:** Modifies data. Always return a value. Never return nothing.

```php
// Action — do something when X happens
add_action( 'hook_name', 'callback_function', $priority, $accepted_args );

// Filter — modify data before it is used
add_filter( 'hook_name', 'callback_function', $priority, $accepted_args );
```

---

## Priority Rules

Default priority is 10. Lower numbers run earlier.

```php
// Run before default (priority 10)
add_action( 'init', 'my_early_function', 5 );

// Run after default
add_action( 'init', 'my_late_function', 20 );

// Run very late — useful for overriding other plugins
add_filter( 'the_content', 'my_content_filter', 99 );
```

**Priority decision rules:**
- Default (10): no timing requirement
- 1–9: must run before most other callbacks
- 11–19: must run after most other callbacks
- 20+: must run after plugins using default priority
- 99+: last resort — only when explicitly overriding known conflicts
- PHP_INT_MAX: guaranteed last (use sparingly — signals a design smell)

---

## Accepted Arguments

`add_action` and `add_filter` accept a 4th argument: how many arguments the callback
will receive. The hook must pass that many arguments or the call fails silently.

```php
// Hook passes: $post_id, $post, $update
// Callback only needs $post_id:
add_action( 'save_post', 'my_save_handler', 10, 1 );

// Callback needs all three:
add_action( 'save_post', 'my_save_handler', 10, 3 );

function my_save_handler( int $post_id, WP_Post $post, bool $update ): void {
    // $post_id, $post, $update all available
}
```

---

## Registering Custom Hooks

Custom hooks must be documented. Every action and filter you register is a contract
with downstream developers.

```php
<?php
/**
 * Fires before an item is processed.
 *
 * @since 1.0.0
 *
 * @param int   $item_id The ID of the item being processed.
 * @param array $data    Raw item data array.
 */
do_action( 'my_plugin_before_process_item', $item_id, $data );

// Process the item.
$result = my_plugin_process( $item_id, $data );

/**
 * Filters the processed item result.
 *
 * @since 1.0.0
 *
 * @param mixed $result  The processed result.
 * @param int   $item_id The ID of the item.
 * @return mixed Filtered result. Must return a value of the same type.
 */
$result = apply_filters( 'my_plugin_process_item_result', $result, $item_id );
```

---

## Unhookable Design

Every callback you register must be unhookable by downstream developers.
Never use anonymous functions for hooks that others might need to remove.

```php
// WRONG — cannot be removed by downstream code
add_action( 'init', function(): void {
    // logic
} );

// CORRECT — removable
add_action( 'init', 'my_plugin_init_handler', 10 );

function my_plugin_init_handler(): void {
    // logic
}

// To remove:
remove_action( 'init', 'my_plugin_init_handler', 10 );

// Class method hooks — also removable if class instance is accessible
class My_Plugin {
    public function init(): void {
        add_action( 'init', [ $this, 'init_handler' ], 10 );
    }
    public function init_handler(): void {
        // logic
    }
}
// To remove:
$instance = my_plugin_get_instance();
remove_action( 'init', [ $instance, 'init_handler' ], 10 );
```

---

## Essential WordPress Hooks

### Timing Hooks (fire in sequence)

| Hook | Fires When | Use For |
|---|---|---|
| `muplugins_loaded` | After mu-plugins load | Almost never |
| `plugins_loaded` | After all plugins load | Plugin compatibility checks, late init |
| `setup_theme` | Before theme setup | Rarely needed |
| `after_setup_theme` | Theme functions.php executed | Theme support, menus |
| `init` | WordPress initialised | CPT/taxonomy registration, most setup |
| `wp_loaded` | All plugins, theme, functions loaded | Post-init tasks |
| `template_redirect` | Before template is loaded | Redirects, access control |
| `wp` | WP query established | Access to queried post/archive |
| `wp_head` | Inside `<head>` | Output meta tags, styles |
| `wp_footer` | Before `</body>` | Output scripts |
| `shutdown` | After response sent | Cleanup, logging |

### Content Hooks

| Hook | Type | Use For |
|---|---|---|
| `the_content` | Filter | Modify post content output |
| `the_title` | Filter | Modify post title output |
| `the_excerpt` | Filter | Modify excerpt output |
| `get_the_excerpt` | Filter | Modify excerpt before caching |
| `wp_title` | Filter | Modify page title (classic) |
| `document_title_parts` | Filter | Modify page title (modern) |
| `body_class` | Filter | Add classes to `<body>` |
| `post_class` | Filter | Add classes to post wrapper |

### Admin Hooks

| Hook | Fires When | Use For |
|---|---|---|
| `admin_menu` | Admin menu built | Register menu pages |
| `admin_init` | Admin initialised | Settings registration, redirects |
| `admin_enqueue_scripts` | Admin scripts enqueue | Load admin assets |
| `add_meta_boxes` | Meta boxes registered | Add custom meta boxes |
| `save_post` | Post saved | Process meta box data |
| `admin_notices` | Admin notices area | Output admin notice HTML |

### WooCommerce Hooks (see woocommerce.md for full list)

| Hook | Type | Use For |
|---|---|---|
| `woocommerce_before_single_product` | Action | Add content before product |
| `woocommerce_after_add_to_cart_button` | Action | Add after cart button |
| `woocommerce_cart_calculate_fees` | Action | Add fees to cart |
| `woocommerce_product_get_price` | Filter | Modify product price |
| `woocommerce_checkout_fields` | Filter | Add/modify checkout fields |
| `woocommerce_thankyou` | Action | Add to order confirmation |

---

## Reference Array Variants

`do_action_ref_array()` and `apply_filters_ref_array()` pass arguments as an
array rather than individual parameters. Used when arguments must be passed
by reference (e.g. modifying `$wp_query` directly). Rare in plugin development;
common in WordPress core.

```php
// Core uses this internally:
do_action_ref_array( 'parse_query', [ &$this ] );

// Receiving it — same add_action() call:
add_action( 'parse_query', 'my_parse_query_handler', 10, 1 );
function my_parse_query_handler( WP_Query $query ): void {
    // $query is passed by reference — modifications affect the main query
    if ( ! is_admin() && $query->is_main_query() && $query->is_archive() ) {
        $query->set( 'posts_per_page', 12 );
    }
}
```

---

## Filter Return Contract

Filters MUST return a value. A filter that does not return breaks the data pipeline.

```php
// WRONG — returns nothing; downstream code receives null
add_filter( 'the_content', function( string $content ): void {
    echo '<div>' . $content . '</div>';
} );

// CORRECT — returns modified value
add_filter( 'the_content', function( string $content ): string {
    return '<div>' . $content . '</div>';
} );

// CORRECT — return original when not modifying
add_filter( 'the_content', function( string $content ): string {
    if ( ! is_singular( 'my_post_type' ) ) {
        return $content; // Not our page — return unchanged
    }
    return '<div class="my-wrapper">' . $content . '</div>';
} );
```

---

## Dynamic Hook Names

Dynamic hooks change based on context. Useful but fragile — document them clearly.

```php
// WooCommerce uses these extensively:
// woocommerce_thankyou_{payment_method}
// manage_{post_type}_posts_columns

// Creating your own:
$post_type = get_post_type();
do_action( "my_plugin_before_display_{$post_type}", $post_id );

// Document the pattern explicitly:
/**
 * Fires before displaying a specific post type's content.
 *
 * The dynamic part of the hook name, `{$post_type}`, refers to the post type slug.
 * For example: `my_plugin_before_display_product`, `my_plugin_before_display_post`.
 *
 * @since 1.0.0
 * @param int $post_id Post ID.
 */
```
